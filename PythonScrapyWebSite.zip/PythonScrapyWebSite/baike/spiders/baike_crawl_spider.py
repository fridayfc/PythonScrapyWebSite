# -*- coding: utf-8 -*-
import re
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from baike.items import BaikeItem
import logging

from scrapy_redis.spiders import RedisCrawlSpider

# logger = logging.getLogger()


class BaikeCrawlSpiderSpider(RedisCrawlSpider):
    name = 'baike_crawl_spider'
    allowed_domains = ['baike.baidu.com']
    # 在运行开始后在redis-cli上输入：
    # lpush BaikeCrawlSpider:start_urls http://baike.baidu.com/
    # 爬虫启动Terminal命令
    # scrapy crawl baike_crawl_spider
    
    redis_key = 'BaikeCrawlSpider:start_urls'

    rules = (
        Rule(LinkExtractor(allow=r'fenlei/'), follow=True),
        Rule(LinkExtractor(allow=r'view/'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        item = BaikeItem()
        item['title'] = response.xpath('//h1//text()').extract_first()
        item['url'] = response.request.url
        # 词条统计部分
        data_block = response.xpath('//dd[@class="description"]')
        item['browse_count'] = data_block.xpath('.//li[1]/span/text()').extract_first()
        edition_unm = data_block.xpath('.//li[2]/text()').extract_first()
        item['edition_num'] = re.findall(r'(\d+)', edition_unm)[0]
        item['last_update_time'] = data_block.xpath('.//li[3]/span/text()').extract_first()
        item['creater_name'] = data_block.xpath('.//li[4]/a/text()').extract_first()
        # 词条顶部信息
        data_block = response.xpath('//div[@class="top-tool"]')
        item['vote_count'] = data_block.xpath('.//span[@class="vote-count"]/text()').extract_first()
        item['share_count'] = data_block.xpath('.//span[@class="share-count"]/text()').extract_first()
        # 词条文本词数
        words = response.xpath('string(//div[@class="main-content"])').extract_first()
        item['words_count'] = len(re.sub(r'\s', "", words))

        return item
