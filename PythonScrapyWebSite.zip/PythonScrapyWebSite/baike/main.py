from scrapy import cmdline
cmdline.execute('scrapy crawl baike_crawl_spider'.split())