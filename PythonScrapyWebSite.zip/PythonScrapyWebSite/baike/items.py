# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class BaikeItem(scrapy.Item):
    # define the fields for your item here like:
    # 词条标题
    title = scrapy.Field()
    # 词条链接
    url = scrapy.Field()
    # 浏览次数
    browse_count = scrapy.Field()
    # 编辑次数
    edition_num = scrapy.Field()
    # 最新更新时间
    last_update_time = scrapy.Field()
    # 创建者名称
    creater_name = scrapy.Field()
    # 文本字数
    words_count = scrapy.Field()
    # 点赞数
    vote_count = scrapy.Field()
    # 转发数
    share_count = scrapy.Field()
